import { useToast } from "@/hooks/use-toast";

export default function Notification() {
  // This component uses the Shadcn Toast component which is already imported in App.tsx
  // No need to create a custom notification component
  return null;
}
